package biz.serviceinterface;

/**
 * @description: TODO
 * @author: anson
 * @Date: 2019/12/25 9:51
 * @version: 1.0
 */
public interface DemoService {

    String test();
}