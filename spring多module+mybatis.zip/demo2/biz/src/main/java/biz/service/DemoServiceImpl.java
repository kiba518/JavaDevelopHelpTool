package biz.service;
import dao.mapper.sys_resourceMapper;
import biz.serviceinterface.DemoService;

import dao.po.sys_resource;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;

/**
 * @description: TODO
 * @author: anson
 * @Date: 2019/12/25 9:51
 * @version: 1.0
 */
@Service
public class DemoServiceImpl implements DemoService {
    @Autowired
    private sys_resourceMapper Mapper;
    @Override
    public String test() {
        List<sys_resource> mp = Mapper.list();
        return ""+mp.size()+mp.get(0).getId();
        //return "test";
    }
}
