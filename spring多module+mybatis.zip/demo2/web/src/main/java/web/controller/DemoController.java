package web.controller;
import biz.serviceinterface.DemoService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;
/**
 * @description: TODO
 * @author: anson
 * @Date: 2019/12/25 9:23
 * @version: 1.0
 */
@RestController
@RequestMapping("demo")
public class DemoController {
    @Autowired
    private DemoService demoService;
    @GetMapping("test")
    public String test() {
        return "Hello World!"+demoService.test();
    }
}
