package web;

import org.mybatis.spring.annotation.MapperScan;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
/*import org.mybatis.spring.annotation.MapperScan;*/
/**
 * @description: TODO
 * @author: anson
 * @Date: 2019/12/25 9:21
 * @version: 1.0
 */
@SpringBootApplication(scanBasePackages = {"web","biz"})
@MapperScan("dao.mapper")
public class WebApplication {

    public static void main(String[] args) {
        SpringApplication.run(WebApplication.class, args);
    }
}
